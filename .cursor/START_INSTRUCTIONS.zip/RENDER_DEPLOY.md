# 🚀 Деплой бота на Render.com

Полная инструкция по развертыванию BTC Pump/Dump бота на платформе Render.

---

## ⚡ Быстрый старт

### 1. Создайте аккаунт на Render

Перейдите на [render.com](https://render.com) и зарегистрируйтесь (можно через GitHub).

### 2. Подготовьте Git репозиторий

```bash
# Если еще не инициализирован
git init
git add .
git commit -m "Production ready bot"

# Загрузите на GitHub
git remote add origin <your-github-repo-url>
git push -u origin main
```

### 3. Создайте новый Web Service на Render

1. Войдите в [Render Dashboard](https://dashboard.render.com)
2. Нажмите **"New +"** → **"Web Service"**
3. Подключите ваш GitHub репозиторий
4. Выберите репозиторий с ботом

### 4. Настройте сервис

**Build & Deploy Settings:**
- **Name:** `btc-pump-dump-bot` (или любое другое)
- **Environment:** `Python 3`
- **Region:** Выберите ближайший регион
- **Branch:** `main` (или ваша ветка)
- **Build Command:** `pip install -r requirements.txt`
- **Start Command:** `python main.py`

**Plan:**
- Выберите **Free** или **Starter** ($7/месяц)
- ⚠️ Free план засыпает после 15 минут неактивности!

### 5. Настройте Environment Variables

В разделе **Environment** добавьте переменные:

| Key | Value | Описание |
|-----|-------|----------|
| `TELEGRAM_BOT_TOKEN` | `ваш_токен_от_BotFather` | **ОБЯЗАТЕЛЬНО** |
| `TRADING_MODE` | `swing` или `day` | Режим торговли |
| `ENVIRONMENT` | `production` | Production режим |
| `HEALTHCHECK_PORT` | `8080` | Порт для healthcheck |
| `ALERT_TELEGRAM_CHAT_ID` | `ваш_telegram_id` | Опционально |

⚠️ **ВАЖНО:** Не забудьте получить новый токен у [@BotFather](https://t.me/BotFather)!

### 6. Настройте Health Check (опционально)

- **Health Check Path:** `/health`
- Это позволит Render мониторить работоспособность бота

### 7. Deploy!

Нажмите **"Create Web Service"** и дождитесь деплоя (~2-3 минуты).

---

## 📊 Мониторинг на Render

### Просмотр логов

```
Dashboard → Your Service → Logs
```

Логи в реальном времени показывают:
- Запуск бота
- Анализы рынка
- Отправленные сигналы
- Ошибки

### Проверка здоровья

```
https://your-app-name.onrender.com/health
https://your-app-name.onrender.com/metrics
```

### Метрики Render

Render предоставляет:
- CPU usage
- Memory usage
- Request rate (для healthcheck)
- Deployment history

---

## 🔄 Автоматические деплои

Render автоматически деплоит при пуше в GitHub:

```bash
git add .
git commit -m "Update bot"
git push origin main
```

Render автоматически:
1. Обнаружит изменения
2. Запустит новый build
3. Остановит старую версию
4. Запустит новую версию

---

## ⚠️ Важные ограничения Render Free Plan

### 🔴 Проблемы Free плана:

1. **Сервис засыпает:** После 15 минут без HTTP запросов
2. **750 часов/месяц:** Только 750 часов работы в месяц
3. **Холодный старт:** После пробуждения запуск занимает 30+ секунд

### ✅ Решения:

#### Вариант 1: Использовать Cron Job для пинга (бесплатно)

Создайте **Cron Job** на Render:

```bash
# Настройки Cron Job:
Name: keep-bot-alive
Schedule: */10 * * * *  (каждые 10 минут)
Command: curl https://your-app-name.onrender.com/health
```

#### Вариант 2: Внешний uptimer (бесплатно)

Используйте сервисы:
- [UptimeRobot](https://uptimerobot.com) - 50 мониторов бесплатно
- [Cronitor](https://cronitor.io) - ping каждые 5 минут
- [Freshping](https://freshping.io)

Настройте пинг на: `https://your-app-name.onrender.com/health`

#### Вариант 3: Starter план ($7/мес)

Без ограничений на активность, работает 24/7.

---

## 🔧 Troubleshooting

### Бот не запускается

**Проверьте логи:**
```
Dashboard → Logs
```

**Частые ошибки:**
- ❌ `No module named 'aiohttp'` → Убедитесь что `requirements.txt` полный
- ❌ `TELEGRAM_BOT_TOKEN not found` → Проверьте Environment Variables
- ❌ `Application failed to respond` → Проверьте `HEALTHCHECK_PORT=8080`

### Healthcheck failing

Render пингует `/health` каждые 30 секунд. Если бот не отвечает:

1. Проверьте что healthcheck сервер запущен
2. Проверьте порт 8080
3. Посмотрите логи на ошибки

### База данных пропадает при редеплое

**Проблема:** SQLite база хранится в контейнере и теряется при редеплое.

**Решение 1:** Использовать Render Disk (платно)

**Решение 2:** PostgreSQL (бесплатно на Render)

Добавьте в `render.yaml`:
```yaml
databases:
  - name: btc-bot-db
    databaseName: btcbot
    user: btcbot
```

**Решение 3:** External Database (Supabase, Railway бесплатно)

---

## 🔐 Безопасность

### ✅ Рекомендации:

1. **Не коммитьте .env файл:**
   ```bash
   # Добавьте в .gitignore
   .env
   btc_signals.db
   bot.log
   __pycache__/
   *.pyc
   ```

2. **Используйте Environment Variables в Render**
   - Все секреты храните в Render Dashboard
   - Никогда не пушьте токены в Git

3. **Регулярно обновляйте токен:**
   - Создайте новый токен у @BotFather
   - Обновите в Render Environment Variables
   - Перезапустите сервис

---

## 💰 Стоимость

### Free Plan (0$/месяц):
- ✅ 750 часов работы
- ✅ Healthcheck endpoints
- ❌ Засыпает после 15 мин
- ❌ Медленный холодный старт

### Starter Plan (7$/месяц):
- ✅ Безлимитные часы
- ✅ Всегда активен (24/7)
- ✅ Быстрый старт
- ✅ Custom domains

---

## 📈 Альтернативы Render

Если Render не подходит:

### 1. **Railway** (бесплатно 5$/мес credits)
- Проще настройка
- PostgreSQL included
- Не засыпает

### 2. **Heroku** ($7/мес)
- Классический вариант
- Много аддонов
- Хорошая документация

### 3. **DigitalOcean App Platform** ($5/мес)
- Больше контроля
- SSD storage included
- 99.99% uptime

### 4. **VPS** (от $5/мес)
- DigitalOcean, Vultr, Linode
- Полный контроль
- Используйте deployment скрипты из `/deployment`

---

## 🎯 Рекомендации

### Для тестирования:
✅ **Render Free** + UptimeRobot для пингов

### Для production с малым трафиком:
✅ **Render Starter** ($7/мес) - оптимальный вариант

### Для серьезного production:
✅ **VPS** ($10-20/мес) - полный контроль и масштабируемость

---

## 📞 Полезные ссылки

- [Render Documentation](https://render.com/docs)
- [Render Dashboard](https://dashboard.render.com)
- [Render Status](https://status.render.com)
- [Community Forum](https://community.render.com)

---

## ✅ Чеклист для деплоя

- [ ] Репозиторий загружен на GitHub
- [ ] Файл `requirements.txt` актуален
- [ ] Файл `render.yaml` создан
- [ ] Получен новый Telegram Bot Token
- [ ] Создан Web Service на Render
- [ ] Environment Variables настроены
- [ ] Healthcheck path указан `/health`
- [ ] Деплой успешно завершился
- [ ] Логи показывают "Bot is ready and running"
- [ ] Healthcheck отвечает 200 OK
- [ ] Бот отвечает в Telegram на /start
- [ ] Настроен uptimer (для Free plan)

---

**🎉 Готово! Ваш бот работает в облаке!**

Теперь можете подписаться на сигналы через Telegram: `/subscribe`
