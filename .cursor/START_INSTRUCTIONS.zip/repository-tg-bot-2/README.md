# 🤖 BTC Pump/Dump Trading Signal Bot

Автоматизированный бот для анализа рынка BTC/USDT и отправки торговых сигналов в Telegram на основе технических индикаторов и машинного обучения.

---

## ⚡ Основные возможности

- 📊 **Анализ в реальном времени:** Мониторинг рынка BTC/USDT на Binance
- 🔮 **ML прогнозирование:** RandomForest модель с fallback на rule-based систему
- 📈 **Технические индикаторы:** RSI, MACD, Bollinger Bands, EMA, VWAP, ATR, Volume, Momentum
- 💹 **Два режима торговли:** Swing trading и Day trading
- 📱 **Telegram интеграция:** Команды, настройки, уведомления
- 🔔 **Персонализация:** Каждый пользователь настраивает минимальную вероятность сигнала
- 📊 **Статистика:** Точность прогнозов, история сигналов
- 🏥 **Production ready:** Healthcheck, мониторинг, graceful shutdown, логи

---

## 🚀 Быстрый старт (локальный запуск)

### 1. Клонирование репозитория

```bash
git clone <your-repo-url>
cd repository-tg-bot-2
```

### 2. Установка зависимостей

```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Настройка конфигурации

```bash
cp .env.example .env
nano .env  # или любой текстовый редактор
```

Обязательно укажите:
- `TELEGRAM_BOT_TOKEN` - получить у [@BotFather](https://t.me/BotFather)
- `TRADING_MODE` - `swing` или `day`

### 4. Запуск

```bash
python main.py
```

Бот начнёт анализировать рынок каждую минуту и отправлять сигналы подписавшимся пользователям.

---

## 📱 Команды Telegram

### Основные команды

- `/start` - Начать работу с ботом
- `/help` - Справка по командам
- `/subscribe` - Подписаться на сигналы
- `/unsubscribe` - Отписаться от сигналов

### Информация

- `/status` - Текущий анализ рынка
- `/stats` - Статистика работы бота
- `/settings` - Персональные настройки

### Настройки пользователя

Через `/settings` можно настроить:
- 🔔 **Уведомления:** Включить/выключить
- 📊 **Минимальная вероятность:** От 50% до 90%
- 🎯 **Типы сигналов:** PUMP, DUMP или оба
- 📈 **Режим торговли:** Swing или Day

---

## 🔧 Конфигурация

### Основные параметры (config.py)

| Параметр | Значение по умолчанию | Описание |
|----------|----------------------|----------|
| `SYMBOL` | BTC/USDT | Торговая пара |
| `TIMEFRAME` | 1m | Таймфрейм для swing |
| `CHECK_INTERVAL` | 60s | Интервал проверки |
| `PUMP_THRESHOLD` | 0.60 | Порог для PUMP сигнала |
| `DUMP_THRESHOLD` | 0.60 | Порог для DUMP сигнала |
| `TRADING_MODE` | swing | Режим торговли |

### Режимы торговли

#### **Swing Trading** (по умолчанию)
- Таймфрейм: 1 минута
- Проверка: каждую минуту
- Подходит для: средне- и долгосрочных позиций

#### **Day Trading**
- Таймфрейм: 1 минута
- Проверка: каждые 30 секунд
- Дополнительные индикаторы: spread, volume surge, consolidation
- Подходит для: внутридневной торговли

---

## 🏗️ Архитектура

```
├── main.py              # Главный модуль, координация
├── telegram_bot.py      # Telegram бот с командами
├── data_collector.py    # Сбор данных с Binance
├── indicators.py        # Технические индикаторы
├── ml_model.py          # ML модель и rule-based логика
├── database.py          # SQLite база данных
├── healthcheck.py       # HTTP healthcheck сервер
├── monitoring.py        # Мониторинг и алерты
├── config.py            # Конфигурация
└── utils.py             # Вспомогательные функции
```

---

## 📊 Технические индикаторы

### Всегда используются:
- **RSI** (Relative Strength Index)
- **MACD** (Moving Average Convergence Divergence)
- **Bollinger Bands**
- **EMA** (Exponential Moving Average)
- **VWAP** (Volume Weighted Average Price)
- **Volume Analysis**
- **Momentum**
- **ATR** (Average True Range)
- **Orderbook Imbalance**
- **Fear & Greed Index**

### Дополнительно для Day Trading:
- **Spread Analysis**
- **Volume Surge Detection**
- **Consolidation Detection**
- **Intraday Trend Strength**

---

## 🤖 ML модель

### Принцип работы:

1. **Обучение** на исторических данных (опционально)
2. **Rule-based fallback** если модель не обучена
3. **Scoring система** на основе индикаторов
4. **Адаптивные пороги** в зависимости от волатильности

### Rule-based scoring:

| Индикатор | Вес | Условие |
|-----------|-----|---------|
| RSI | ±2 | Экстремальные значения |
| MACD | ±2 | Кроссовер |
| Bollinger Bands | ±2 | Выход за границы |
| Volume | ±1 | Подтверждение |
| Price Change | ±1 | >3% за час |
| Fear & Greed | ±1 | Экстремальные значения |

---

## 🏥 Production возможности

### Healthcheck HTTP сервер

Бот предоставляет HTTP эндпоинты на порту 8080:

- `GET /health` - Liveness probe (200 OK если процесс жив)
- `GET /ready` - Readiness probe (503 если нет свежего анализа)
- `GET /metrics` - Метрики работы бота

**Пример:**
```bash
curl http://localhost:8080/metrics
```

**Ответ:**
```json
{
  "uptime_seconds": 3600,
  "status": "ready",
  "total_analyses": 60,
  "total_signals_sent": 5,
  "errors_count": 0,
  "system": {
    "memory_mb": 145.23,
    "cpu_percent": 2.5,
    "pid": 12345
  }
}
```

### Graceful shutdown

Бот корректно обрабатывает SIGTERM и SIGINT:
- Останавливает новые анализы
- Завершает текущие задачи
- Закрывает соединения
- Останавливает HTTP сервер

### Логирование

- **Ротация:** Автоматическая ротация при 10MB (5 файлов)
- **Формат:** Timestamp, модуль, уровень, файл:строка, сообщение
- **Уровень:** INFO по умолчанию

---

## 📦 Деплой на production

Полное руководство: [deployment/README.md](deployment/README.md)

### Быстрая установка (Ubuntu/Debian):

```bash
# 1. Клонирование
cd /opt
sudo git clone <repo-url> btc-bot
cd btc-bot

# 2. Установка зависимостей
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 3. Настройка
cp .env.example .env
nano .env  # Укажите TELEGRAM_BOT_TOKEN

# 4. Создание systemd service
sudo cp deployment/btc-bot.service /etc/systemd/system/
sudo systemctl enable btc-bot
sudo systemctl start btc-bot

# 5. Проверка
sudo systemctl status btc-bot
curl http://localhost:8080/health
```

### Автоматический деплой:

```bash
sudo ./deployment/deploy.sh
```

---

## 🔄 Обновление

```bash
cd /opt/btc-bot
sudo ./deployment/deploy.sh
```

Скрипт автоматически:
1. Остановит бота
2. Создаст бэкап БД
3. Обновит код из репозитория
4. Обновит зависимости
5. Проверит конфигурацию
6. Запустит бота
7. Проверит healthcheck

---

## 💾 Бэкапы

### Автоматические бэкапы (cron):

```bash
sudo cp deployment/backup.sh /usr/local/bin/
sudo chmod +x /usr/local/bin/backup.sh
sudo crontab -e
```

Добавьте:
```
0 3 * * * /usr/local/bin/backup.sh
```

### Ручной бэкап:

```bash
sudo /usr/local/bin/backup.sh
```

Бэкапы хранятся 7 дней в `/opt/btc-bot/backups/`

---

## 📈 Мониторинг

### Логи

```bash
# Real-time логи
sudo journalctl -u btc-bot -f

# Только ошибки
sudo journalctl -u btc-bot -p err

# Файл логов
tail -f /opt/btc-bot/bot.log
```

### Метрики

```bash
# Системные метрики
curl http://localhost:8080/metrics | jq

# Статус
curl http://localhost:8080/ready
```

### Алерты (опционально)

Запустите monitoring процесс:
```bash
python monitoring.py
```

---

## 🔐 Безопасность

- ✅ Токен хранится в `.env` с правами 600
- ✅ Systemd запускает от отдельного пользователя
- ✅ Нет hardcoded секретов
- ✅ Rate limiting для Telegram API
- ✅ Graceful shutdown предотвращает data corruption

---

## 🛠️ Troubleshooting

### Проблема: Бот не запускается

```bash
# Проверьте логи
sudo journalctl -u btc-bot -n 50

# Проверьте конфигурацию
python -c "import config"

# Проверьте токен
cat .env | grep TELEGRAM_BOT_TOKEN
```

### Проблема: Нет сигналов

- Проверьте режим торговли в `.env`
- Проверьте пороги в `config.py` (PUMP/DUMP_THRESHOLD)
- Проверьте логи анализа: `tail -f bot.log | grep "Analysis complete"`

### Проблема: Высокое использование памяти

```bash
# Проверьте метрики
curl http://localhost:8080/metrics

# Перезапустите
sudo systemctl restart btc-bot
```

---

## 📝 Зависимости

- Python 3.10+
- python-telegram-bot >= 20.0
- ccxt >= 4.0.0
- pandas >= 2.0.0
- scikit-learn >= 1.3.0
- aiohttp >= 3.9.0
- psutil >= 5.9.0

Полный список: [requirements.txt](requirements.txt)

---

## 📄 Лицензия

MIT License

---

## 🤝 Contributing

Pull requests приветствуются! Для больших изменений сначала откройте issue.

---

## ⚠️ Дисклеймер

Этот бот предназначен только для образовательных целей. Торговля криптовалютами сопряжена с риском. Не инвестируйте средства, которые не можете позволить себе потерять. Всегда проводите собственное исследование.

---

## 📞 Поддержка

- 📖 Документация: [deployment/README.md](deployment/README.md)
- 🐛 Issues: GitHub Issues
- 💬 Telegram: @your_support_bot

---

**Made with ❤️ for crypto traders**
