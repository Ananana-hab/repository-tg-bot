# 🚀 ИНСТРУКЦИЯ ПО ЗАПУСКУ БОТА

## ✅ ПРОБЛЕМА РЕШЕНА

Ошибка `Conflict: terminated by other getUpdates request` решена!

Telegram webhook был успешно очищен.

---

## 📋 ЗАПУСК БОТА

### Вариант 1: Автоматический (рекомендуется)

```powershell
.\start_bot.ps1
```

Этот скрипт:
1. Проверит запущенные Python процессы
2. Остановит их при необходимости
3. Очистит Telegram webhook
4. Запустит бота

### Вариант 2: Ручной

1. **Остановите все Python процессы:**
```powershell
Get-Process python -ErrorAction SilentlyContinue | Stop-Process -Force
```

2. **Очистите Telegram webhook:**
```powershell
python clear_telegram.py
```

3. **Запустите бота:**
```powershell
python main.py
```

---

## ⚠️ ВАЖНО

### Если снова появляется ошибка Conflict:

1. **Проверьте другие экземпляры:**
   - Другие терминалы/консоли
   - Фоновые процессы Python
   - Запуск через IDE (PyCharm, VS Code)

2. **Остановите ВСЕ Python процессы:**
```powershell
Stop-Process -Name python -Force
```

3. **Очистите webhook:**
```powershell
python clear_telegram.py
```

4. **Подождите 5-10 секунд** перед повторным запуском

---

## 📊 ЧТО РАБОТАЕТ

✅ **Фаза 1 + Фаза 2 реализованы:**
- Anti-spam по цене (0.15%)
- Open Interest интеграция
- RSI/MACD удалены
- Новая логика сигналов
- UTC время исправлено

✅ **Текущие показатели:**
- Price: $103,805
- Signal: PUMP (65%)
- Momentum: 586.28
- OI: 85,775 BTC
- Volume: 0.71x

---

## 🔧 TROUBLESHOOTING

### Ошибка: "Bot not accessible"
- Проверьте TELEGRAM_BOT_TOKEN в config.py
- Проверьте интернет соединение

### Ошибка: "No module named..."
- Установите зависимости: `pip install -r requirements.txt`

### Бот запускается но не отвечает
- Проверьте что бот добавлен в канал
- Проверьте права бота в канале
- Используйте /start для активации

---

## 📞 SUPPORT

Если проблема сохраняется:
1. Запустите `python clear_telegram.py`
2. Покажите вывод
3. Проверьте логи в `bot.log`

---

**Последнее обновление:** 09.11.2025, 18:40 UTC+3
